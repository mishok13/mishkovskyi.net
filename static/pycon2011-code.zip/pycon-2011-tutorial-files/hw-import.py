from mapnik import (PolygonSymbolizer, LineSymbolizer,
                    Rule, Style, Color,
                    Layer, Shapefile,
                    Map, Image, render)
