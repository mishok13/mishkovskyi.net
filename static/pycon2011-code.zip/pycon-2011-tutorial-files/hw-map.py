m = Map(800, 400)
m.background = Color('white')
m.append_style('world', style)
m.layers.append(layer)
