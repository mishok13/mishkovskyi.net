rule = Rule()
rule.symbols.append(PolygonSymbolizer(Color("grey")))
rule.symbols.append(LineSymbolizer(Color("black"), 0.1))
