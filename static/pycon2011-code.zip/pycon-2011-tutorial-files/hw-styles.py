style = Style()
style.rules.append(rule)
