SELECT ST_AsWKT(way) FROM planet_osm_point WHERE name="Hyatt Regency Hotel" && ;
